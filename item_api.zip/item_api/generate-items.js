const fs = require("fs");
const path = require("path");

// Read .env without installing any npm packages.
function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const equals = trimmed.indexOf("=");
    if (equals < 1) continue;
    const key = trimmed.slice(0, equals).trim();
    let value = trimmed.slice(equals + 1).trim();
    value = value.replace(/^['"]|['"]$/g, "");
    if (!process.env[key]) process.env[key] = value;
  }
}

const root = __dirname;
loadEnv(path.join(root, ".env"));
const adminDomain = (process.env.ADMIN_DOMAIN || "").replace(/\/+$/, "");
if (!adminDomain) {
  console.error("ADMIN_DOMAIN is missing. Set it in the .env file.");
  process.exit(1);
}

const inputFile = path.join(root, "iteminfo.json");
const outputDir = path.join(root, "items");
const items = JSON.parse(fs.readFileSync(inputFile, "utf8"));
fs.mkdirSync(outputDir, { recursive: true });

let count = 0;
for (const item of items) {
  if (item.itemID == null || !item.icon) {
    console.warn("Skipping item with missing itemID or icon:", item.itemID);
    continue;
  }
  const icon = String(item.icon);
  const updatedItem = {
    ...item,
    Img: `${ADMIN_DOMAIN}/300x300pngs/${encodeURIComponent(icon)}.png`
  };
  const outputFile = path.join(outputDir, `${String(item.itemID)}.json`);
  fs.writeFileSync(outputFile, JSON.stringify(updatedItem, null, 2) + "\n", "utf8");
  count++;
}
console.log(`Generated ${count} item JSON files in ${outputDir}`);
