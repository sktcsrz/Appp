# Item JSON API with generated Img URLs

This project contains one JSON file per item ID, with an added `Img` field.

## 1. Configure the image domain

Edit `.env`:

```dotenv
ADMIN_DOMAIN=https://example.com
```

Replace `https://example.com` with your image host domain. Do not add `/300x300pngs` at the end.

For an item with `icon` equal to `Icon_face_female01_head`, the generator creates:

`https://example.com/300x300pngs/Icon_face_female01_head.png`

## 2. Regenerate item files (optional)

Install Node.js, then run this command in the project folder:

```bash
node generate-items.js
```

No npm packages are required. It reads `iteminfo.json` and `.env`, then creates/updates files in `items/`.

## 3. Publish as a static GET API

Upload the `items` folder to your GitHub repository and enable GitHub Pages. An item can then be requested with GET:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/items/101000001.json`

The generated `items` files included in this ZIP use `https://example.com` as a placeholder until you configure your real domain and rerun the generator.
